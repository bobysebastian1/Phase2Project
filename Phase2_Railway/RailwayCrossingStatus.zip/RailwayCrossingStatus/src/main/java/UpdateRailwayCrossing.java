

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.hibernate.model.*;
import com.hibernate.services.*;

/**
 * Servlet implementation class UpdateRailwayCrossing
 */
@WebServlet("/UpdateRailwayCrossing")
public class UpdateRailwayCrossing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateRailwayCrossing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int cid = Integer.parseInt(request.getParameter("cid"));
		String cname = request.getParameter("cname");
		String cstatus = request.getParameter("cstatus");
		String cschedule = request.getParameter("cschedule");
		String cpersoncharge = request.getParameter("cpersoncharge");

		

		RailwayCrossing std = new RailwayCrossing();
		UserOperations sos = new UserOperations();
		
		std.setCid(cid);
		std.setCname(cname);
		std.setCstatus(cstatus);
		std.setCschedule(cschedule);
		std.setCpersoncharge(cpersoncharge);
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String res = sos.UpdateRailwayCrossing(std);
		if(res.equals("Success"))
			response.sendRedirect("ShowAllUsers.jsp");
		else
			response.sendRedirect("ShowAllUsers.jsp");

		

	}
	

}
