package com.hibernate.services;

import java.io.Serializable;
import java.util.List;

import javax.persistence.TypedQuery;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.hibernate.dbconn.HibernateConfig;
import com.hibernate.model.User;
import com.hibernate.model.RailwayCrossing;
import com.hibernate.model.Favourite;

public class UserOperations {
	private SessionFactory sfactory = null;
	public UserOperations()
	{
		sfactory = HibernateConfig.getSessionFactory();
	}
	
	public String AddNewUser(User usr)
	{
		String result = "Error";
		Session sObj = sfactory.openSession();
		Transaction trns = sObj.beginTransaction();
		Serializable s = sObj.save(usr);
		trns.commit();
		
		if(s!=null)
			result =  "Success";
		
		return result;
	}
	
	public List<User>  ShowAll()
	{
		Session sObj = sfactory.openSession();
		Query qry = sObj.createQuery("from User");  
		List<User>  sall = qry.list();
		return sall;
	}
	
	public String Add(RailwayCrossing rc)
	{
		String result = "Error";
		Session seObj = sfactory.openSession();
		Transaction trans = seObj.beginTransaction();
		Serializable se = seObj.save(rc);
		trans.commit();
		
		if(se!=null)
			result =  "Success";
		
		return result;
	}
	
	public List<RailwayCrossing>  ShowAllCrossings()
	{
		Session seObj = sfactory.openSession();
		Query qry = seObj.createQuery("from RailwayCrossing");  
		List<RailwayCrossing>  sallr = qry.list();
		return sallr;
	}
	
	public boolean DeleteCrossing(int cid)
	{
		boolean b = false;
		Session sObj = sfactory.openSession();
		Transaction trans = sObj.beginTransaction();
		Query qry = sObj.createQuery("Delete from RailwayCrossing where cid=:r");
		qry.setParameter("r", cid);
		int res = qry.executeUpdate();
		if(res>=1)
			b = true;
		
		return b;
}
	public String UpdateRailwayCrossing(RailwayCrossing rc)
	{
		String result = "Error";
		Session sObj = sfactory.openSession();
		Transaction trans = sObj.beginTransaction();
		Query qry = sObj.createQuery("Update RailwayCrossing set cname=:cn, cstatus=:st, cpersoncharge=:pc, cschedule=:cs where cid=:r");
		qry.setParameter("cs", rc.getCschedule());
		qry.setParameter("r", rc.getCid());
		qry.setParameter("cn", rc.getCname());
		qry.setParameter("pc", rc.getCpersoncharge());
		qry.setParameter("st", rc.getCstatus());
		int res = qry.executeUpdate();
		if(res>=1)
			result = "Success";
		
		return result;
	}
	
	public RailwayCrossing SearchCrossing(int cid)
	{
		RailwayCrossing rc = null;
		Session sObj = sfactory.openSession();
		Query qry = sObj.createQuery("from RailwayCrossing where cid=:r");
								
		qry.setParameter("r", cid);
		List<RailwayCrossing>  sall =  qry.list();
		
		if(!sall.isEmpty())
			rc = sall.get(0);
		
		return rc;
	}
	
	
	public User UserCheck(String email, String pwd)
	{
		User std = null;
		Session session = sfactory.openSession();
		TypedQuery qry = session.createQuery("from User where email=:em and pwd=:pwd");
		qry.setParameter("em", email);
		qry.setParameter("pwd", pwd);
		List<User> sall = qry.getResultList();
		
		if(!sall.isEmpty())
			std = sall.get(0);
		
		return std;
	}
	
	public boolean AddFavourite(int cid)
	{
		boolean b = false;
		String result = "Error";
		Session seObj = sfactory.openSession();
		Transaction trans = seObj.beginTransaction();
		TypedQuery qry = seObj.createQuery("INSERT INTO Favourite FROM RailwayCrossing Where cid=:r");
		qry.setParameter("r",cid);
		int res = qry.executeUpdate();
		if(res>=1)
			b = true;
		
		return b;
		
	}
	
	public List<Favourite>  ShowAllFavourite()
	{
		Session seObj = sfactory.openSession();
		Query qry = seObj.createQuery("from Favourite");  
		List<Favourite>  sallf = qry.list();
		return sallf;
	}
}
