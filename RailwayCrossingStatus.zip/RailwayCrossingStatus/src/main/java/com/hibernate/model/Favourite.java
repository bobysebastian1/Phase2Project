package com.hibernate.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

public class Favourite {
	@Entity
	@Table(name="FavouriteCrossingInformation")
	public class RailwayCrossing {
		
		@Id
		@GeneratedValue
		@Column(name="CrossingID")
		private int cid;
		@Column(name="CrossingName")
		private String cname;
		@Column(name="CrossingStatus")
		private String cstatus;
		@Column(name="PersonInCharge")
		private String cpersoncharge;
		@Column(name="TrainSchedule")
		private String cschedule;
		@Column(name="LandMark")
		private String clandmark;
		@Column(name="Address")
		private String caddress;
		public int getCid() {
			return cid;
		}
		public void setCid(int cid) {
			this.cid = cid;
		}
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public String getCstatus() {
			return cstatus;
		}
		public void setCstatus(String cstatus) {
			this.cstatus = cstatus;
		}
		public String getCpersoncharge() {
			return cpersoncharge;
		}
		public void setCpersoncharge(String cpersoncharge) {
			this.cpersoncharge = cpersoncharge;
		}
		public String getCschedule() {
			return cschedule;
		}
		public void setCschedule(String cschedule) {
			this.cschedule = cschedule;
		}
		public String getClandmark() {
			return clandmark;
		}
		public void setClandmark(String clandmark) {
			this.clandmark = clandmark;
		}
		public String getCaddress() {
			return caddress;
		}
		public void setCaddress(String caddress) {
			this.caddress = caddress;
		}
		
		
		
	}
}
