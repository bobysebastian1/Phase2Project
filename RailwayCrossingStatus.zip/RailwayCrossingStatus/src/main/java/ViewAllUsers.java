

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hibernate.model.User;
import com.hibernate.services.UserOperations;

/**
 * Servlet implementation class ViewAllUsers
 */
@WebServlet("/ViewAllUsers")
public class ViewAllUsers extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ViewAllUsers() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		UserOperations userOperations = new UserOperations();
        List<User> userList = userOperations.ShowAll();

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.print("<h2 style=\"text-align:center;width:100%;\">Railway Crossing</h2>");
        out.print("<h4 style=\"text-align:center;width:100%;\">View All Users</h4>");

		out.print("<table width='100%' border='1'>");
		out.println("<tr><th>User ID</th><th>User Name</th><th>Email</th><th>Password</th></tr>");
		for (User usr : userList) { 
				
				
		out.println("<tr>");
		out.print("<td>" + usr.getUid() + "</td>");
		out.print("<td>"+ usr.getUname()+ "</td>");
		out.print("<td>" + usr.getEmail() + "</td>");
		out.print("<td>" + usr.getPwd() + "</td>");
		out.println("</tr>");
	}

	}
	
}
