

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hibernate.model.User;
import com.hibernate.services.UserOperations;

/**
 * Servlet implementation class Users
 */
@WebServlet("/Users")
public class Users extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Users() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		String uname = request.getParameter("uname");
		String email = request.getParameter("email");
		String pwd = request.getParameter("pwd");
		User usr = new User();
		UserOperations so = new UserOperations();
		
		usr.setUname(uname);;
		usr.setEmail(email);
		usr.setPwd(pwd);
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String res = so.AddNewUser(usr);
		if(res.equals("Success"))
			out.print("User has been added Successfully");
		 	
	}

}
