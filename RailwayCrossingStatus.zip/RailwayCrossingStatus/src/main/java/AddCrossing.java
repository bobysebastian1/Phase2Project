

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hibernate.model.*;
import com.hibernate.services.UserOperations;

/**
 * Servlet implementation class AddCrossing
 */
@WebServlet("/AddCrossing")
public class AddCrossing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddCrossing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String cname = request.getParameter("cname");
		String cstatus = request.getParameter("cstatus");
		String cpersoncharge = request.getParameter("cpersoncharge");
		String cschedule = request.getParameter("cschedule");
		String clandmark = request.getParameter("clandmark");
		String caddress = request.getParameter("caddress");
		
		
		RailwayCrossing rc = new RailwayCrossing();
		UserOperations uo = new UserOperations();
		
		
		rc.setCname(cname);
		rc.setCaddress(caddress);
		rc.setCpersoncharge(cpersoncharge);
		rc.setCschedule(cschedule);
		rc.setClandmark(clandmark);
		rc.setCstatus(cstatus);
		
		
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		String res = uo.Add(rc);
		if(res.equals("Success"))
			out.print("Railway Crossing has been added Successfully");
	
	}

}
