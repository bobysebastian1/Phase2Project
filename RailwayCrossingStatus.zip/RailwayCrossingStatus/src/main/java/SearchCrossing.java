

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hibernate.model.RailwayCrossing;
import com.hibernate.services.UserOperations;

/**
 * Servlet implementation class SearchCrossing
 */
@WebServlet("/SearchCrossing")
public class SearchCrossing extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SearchCrossing() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		int cid = Integer.parseInt(request.getParameter("cid"));
		
		UserOperations uo = new UserOperations();
		
		RailwayCrossing rc1 = uo.SearchCrossing(cid);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		if(rc1!=null) {
			
			out.println("<h2 style=\"text-align:center;width:100%;\">Your Search Result:</h2>");
			out.print("<table width='100%' border='1'>");
			out.println("<tr><th>ID</th><th>Crossing Name</th><th>Address</th><th>LandMark</th><th>Status</th><th>Person In Charge</th><th>Schedule</th><th>Add Favourites</th></tr>");
		
			
			out.println("<tr>");
			out.print("<td>" + rc1.getCid() + "</td>");
			out.print("<td>" + rc1.getCname()+ "</td>");
			out.print("<td>" + rc1.getCaddress() + "</td>");
			out.print("<td>" + rc1.getClandmark() + "</td>");
			out.print("<td>" + rc1.getCschedule() + "</td>");
			out.print("<td>" + rc1.getCstatus() + "</td>");
			out.print("<td>" + rc1.getCpersoncharge() + "</td>");
		}
		else
			out.println("<h1>No Crossings Found....</h1>");
	}
	
	
	

}
